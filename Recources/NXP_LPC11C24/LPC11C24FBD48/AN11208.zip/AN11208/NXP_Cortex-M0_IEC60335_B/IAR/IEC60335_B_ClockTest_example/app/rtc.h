#ifndef __RTC_H_
#define __RTC_H_


void RTC_Init(void);

#endif
