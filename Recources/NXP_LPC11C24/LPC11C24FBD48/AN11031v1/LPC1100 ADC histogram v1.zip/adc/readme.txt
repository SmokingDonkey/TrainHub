Sample software to accompany the application note:
"PCB layout and ADC circuit recommendation for LPC1100 and LPC1300"

This sample software is designed to be run with the LPCXpresso debugger.

To execute this software example:
1. Use the "Import existing projects" wizard to setup the project 
   build environment. Select the LPC1100 or LPC1300 project depending
   on the microcontroller that you are using.
2. Connect the LPCXpresso to the workstation and build the projects.
   To build all projects, select "Build all projects".
3. Connect an external power supply to the LPCXpresso board's P1.11 (AD7).
   Make sure to supply a voltage between 0V and 3.3V
   The application note example suggests 1.6V
4. Debug and run the "adc" project.
   The program output is captured on the LPCXpresso "Console" window.
5. After the test has run, copy and paste the raw data into a spreadsheet
   program to plot a scatter chart.

