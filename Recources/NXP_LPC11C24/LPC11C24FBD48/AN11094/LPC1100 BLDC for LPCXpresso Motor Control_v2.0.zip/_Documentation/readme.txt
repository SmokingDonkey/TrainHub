/************************************************************************/
/* 	Quick Start-up Guide for the LPCXpresso Motor Control Kit			*/
/************************************************************************/

---- WELCOME ------------------------------------------------------------
First of all congratulations with purchasing the LPCXpresso Motor Control
Kit.
This package contains all documents and sources needed for a quick 
start-up with the LPCXpresso Motor Control Kit. 
We hope you enjoy working with this Motor Control Evaluation Kit

---- DIRECTORY STRUCTURE ------------------------------------------------
lpcxpresso_motor_control	-> 	Main directory
	+ _Documentation		-> 	Contains all necessary documents to 
	|							have a quick start-up with this kit
	+ BLDC_Sensored 		->	This directory contains all sources 
	|							for the LPC11xx/LPC11Cxx BLDC sensored 
	|							demonstrator.
	+ CMSISv1p30_LPC11x		->	CMSIS standard library
	|
	+ lib_small_printf_m0	-> 	Small size printf library.					

---- SOURCE CODE --------------------------------------------------------
To be able to run this source code in LPCXpresso, you need to import the 
added zip-file.

STEP BY STEP
1. Launch LPCXpresso, create a workspace on your prefered location.
2. Open in the 'Quick Start panel', the 'Start here' section.
3. Use the 'Import Example Project(s)' wizard for importing the zip-file
	
---- INFORMATION --------------------------------------------------------
For more and all the latest information please visit the following 
websites:
-	LPCXpresso Motor Control Kit
	http://www.embeddedartists.com/products/lpcxpresso/xpr_motor.php
	Login into the support page to get access to much more information 
	of this kit.
	
-	NXP Microcontrollers website:
	http://ics.nxp.com/microcontrollers/

-	Datasheets and User Manuals for the LPC1000 series
	http://ics.nxp.com/products/lpc1000/all/

---- DISCLAIMER ---------------------------------------------------------	
/***********************************************************************
 * Software that is described herein is for illustrative purposes only
 * which provides customers with programming information regarding the
 * products. This software is supplied "AS IS" without any warranties.
 * NXP Semiconductors assumes no responsibility or liability for the
 * use of the software, conveys no license or title under any patent,
 * copyright, or mask work right to the product. NXP Semiconductors
 * reserves the right to make changes in the software without
 * notification. NXP Semiconductors also make no representation or
 * warranty that such application will be suitable for the specified
 * use without further testing or modification.
 **********************************************************************/
	